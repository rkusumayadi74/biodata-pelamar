<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }


    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }


    public function changePassword()
    {
        $data['title'] = 'Change Password';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[3]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[3]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong current password!</div>');
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New password cannot be the same as current password!</div>');
                    redirect('user/changepassword');
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password changed!</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }

    public function biodata()
    {
        $data['title'] = 'Data Pribadi Pelamar';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');
        $this->form_validation->set_rules('no_ktp', 'No. KTP', 'required|trim');
        $this->form_validation->set_rules('tempat_tanggal_lahir', 'Tempat, Tanggal Lahir', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required|trim');
        $this->form_validation->set_rules('agama', 'Agama', 'required|trim');
        $this->form_validation->set_rules('golongan_darah', 'Golongan Darah', 'required|trim');
        $this->form_validation->set_rules('status', 'Status', 'required|trim');
        $this->form_validation->set_rules('alamat_ktp', 'Alamat KTP', 'required|trim');
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required|trim');
        $this->form_validation->set_rules('no_telp', 'No. Telepon', 'required|trim');
        $this->form_validation->set_rules('org_terdekat', 'Orang Terdekat', 'required|trim');
        $this->form_validation->set_rules('pendidikan', 'Pendidikan Terakhir', 'required|trim');
        $this->form_validation->set_rules('riwayat_pelatihan', 'Riwayat Pelatihan', 'required|trim');
        $this->form_validation->set_rules('riwayat_kerja', 'Riwayat Pekerjaan', 'required|trim');
        $this->form_validation->set_rules('skill', 'Skill', 'required|trim');
        $this->form_validation->set_rules('penempatan_kerja', 'Penempatan Kerja', 'required|trim');
        $this->form_validation->set_rules('penghasilan', 'Penghasilan', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/biodata', $data);
            $this->load->view('templates/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $posisi = $this->input->post('posisi');
            $no_ktp = $this->input->post('no_ktp');
            $tempat_tanggal_lahir = $this->input->post('tempat_tanggal_lahir');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $agama = $this->input->post('agama');
            $golongan_darah = $this->input->post('golongan_darah');
            $status = $this->input->post('status');
            $alamat_ktp = $this->input->post('alamat_ktp');
            $alamat_tinggal = $this->input->post('alamat_tinggal');
            $no_telp = $this->input->post('no_telp');
            $org_terdekat = $this->input->post('org_terdekat');
            $pendidikan = $this->input->post('pendidikan');
            $riwayat_pelatihan = $this->input->post('riwayat_pelatihan');
            $riwayat_kerja = $this->input->post('riwayat_kerja');
            $skill = $this->input->post('skill');
            $penempatan_kerja = $this->input->post('penempatan_kerja');
            $penghasilan = $this->input->post('penghasilan');

            /*// cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }*/

            $this->db->set('name', $name);
            $this->db->set('posisi', $posisi);
            $this->db->set('no_ktp', $no_ktp);
            $this->db->set('tempat_tanggal_lahir', $tempat_tanggal_lahir);
            $this->db->set('jenis_kelamin', $jenis_kelamin);
            $this->db->set('agama', $agama);
            $this->db->set('golongan_darah', $golongan_darah);
            $this->db->set('status', $status);
            $this->db->set('alamat_ktp', $alamat_ktp);
            $this->db->set('alamat_tinggal', $alamat_tinggal);
            $this->db->set('no_telp', $no_telp);
            $this->db->set('org_terdekat', $org_terdekat);
            $this->db->set('pendidikan', $pendidikan);
            $this->db->set('riwayat_pelatihan', $riwayat_pelatihan);
            $this->db->set('riwayat_kerja', $riwayat_kerja);
            $this->db->set('skill', $skill);
            $this->db->set('penempatan_kerja', $penempatan_kerja);
            $this->db->set('penghasilan', $penghasilan);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }
}
