<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }


    public function role()
    {
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
    }


    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer');
    }


    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access Changed!</div>');
    }


    public function datapelamar()
    {
        $data['title'] = 'Data Biodata Pelamar';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->model('Data_model', 'data');

        $data['dataPelamar'] = $this->data->getDataPelamar();
        $data['data'] = $this->db->get('user')->result_array();

        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('name', 'Nama', 'required');
        $this->form_validation->set_rules('posisi', 'Posisi yang Dilamar', 'required');
        $this->form_validation->set_rules('no_ktp', 'No. KTP', 'required');
        $this->form_validation->set_rules('tempat_tanggal_lahir', 'Tempat, Tanggal Lahir', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('agama', 'Agama', 'required');
        $this->form_validation->set_rules('golongan_darah', 'Golongan Darah', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
        $this->form_validation->set_rules('alamat_ktp', 'Alamat KTP', 'required');
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required');
        $this->form_validation->set_rules('no_telp', 'No. Telpon', 'required');
        $this->form_validation->set_rules('org_terdekat', 'Orang Terdekat Yang dapat Dihubungi', 'required');
        $this->form_validation->set_rules('pendidikan', 'Pendidikan Terakhir', 'required');
        $this->form_validation->set_rules('riwayat_pelatihan', 'Riwayat Pelatihan', 'required');
        $this->form_validation->set_rules('riwayat_kerja', 'Riwayat Pekerjaan', 'required');
        $this->form_validation->set_rules('skill', 'Skill', 'required');
        $this->form_validation->set_rules('penempatan_kerja', 'Bersedia Ditempatkan di Seluruh Kantor Perusahaan', 'required');
        $this->form_validation->set_rules('penghasilan', 'Penghasilan yang di Harapkan', 'required');

        if ($this->form_validation->run() ==  false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/datapelamar', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'email' => $this->input->post('email'),
                'name' => $this->input->post('name'),
                'posisi' => $this->input->post('posisi'),
                'no_ktp' => $this->input->post('no_ktp'),
                'tempat_tanggal_lahir' => $this->input->post('tempat_tanggal_lahir'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                'agama' => $this->input->post('agama'),
                'golongan_darah' => $this->input->post('golongan_darah'),
                'status' => $this->input->post('status'),
                'alamat_ktp' => $this->input->post('alamat_ktp'),
                'alamat_tinggal' => $this->input->post('alamat_tinggal'),
                'no_telp' => $this->input->post('no_telp'),
                'org_terdekat' => $this->input->post('org_terdekat'),
                'pendidikan' => $this->input->post('pendidikan'),
                'riwayat_pelatihan' => $this->input->post('riwayat_pelatihan'),
                'riwayat_kerja' => $this->input->post('riwayat_kerja'),
                'skill' => $this->input->post('skill'),
                'penempatan_kerja' => $this->input->post('penempatan_kerja'),
                'penghasilan' => $this->input->post('penghasilan')
            ];
            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New sub menu added!</div>');
            redirect('admin/datapelamar');
        }
    }
}
