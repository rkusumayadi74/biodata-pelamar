<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


    <div class="row">
        <div class="col-lg-8">

            <?= form_open_multipart('user/biodata'); ?>
            <div class="form-group row">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="email" name="email" value="<?= $user['email']; ?>" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label for="name" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name" value="<?= $user['name']; ?>">
                    <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="posisi" class="col-sm-2 col-form-label">Posisi yang Dilamar</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="posisi" name="posisi" value="<?= $user['posisi']; ?>">
                    <?= form_error('posisi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="no_ktp" class="col-sm-2 col-form-label">No. KTP</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="no_ktp" name="no_ktp" value="<?= $user['no_ktp']; ?>">
                    <?= form_error('no_ktp', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="ttl" class="col-sm-2 col-form-label">Tempat, Tanggal Lahir</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="tempat_tanggal_lahir" name="tempat_tanggal_lahir" value="<?= $user['tempat_tanggal_lahir']; ?>">
                    <?= form_error('tempat_tanggal_lahir', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" value="<?= $user['jenis_kelamin']; ?>">
                    <?= form_error('jenis_kelamin', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="agama" class="col-sm-2 col-form-label">Agama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="agama" name="agama" value="<?= $user['agama']; ?>">
                    <?= form_error('agama', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="golongan_darah" class="col-sm-2 col-form-label">Golongan Darah</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="golongan_darah" name="golongan_darah" value="<?= $user['golongan_darah']; ?>">
                    <?= form_error('golongan_darah', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="status" class="col-sm-2 col-form-label">Status</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="status" name="status" value="<?= $user['status']; ?>">
                    <?= form_error('status', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="alamat_ktp" class="col-sm-2 col-form-label">Alamat KTP</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="alamat_ktp" name="alamat_ktp" value="<?= $user['alamat_ktp']; ?>">
                    <?= form_error('alamat_ktp', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="alamat_tinggal" class="col-sm-2 col-form-label">Alamat Tinggal</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="alamat_tinggal" name="alamat_tinggal" value="<?= $user['alamat_tinggal']; ?>">
                    <?= form_error('alamat_tinggal', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="no_telp" class="col-sm-2 col-form-label">No. Telpon</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="no_telp" name="no_telp" value="<?= $user['no_telp']; ?>">
                    <?= form_error('no_telp', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="org_terdekat" class="col-sm-2 col-form-label">Orang Terdekat Yang Dapat Dihubungi</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="org_terdekat" name="org_terdekat" value="<?= $user['org_terdekat']; ?>">
                    <?= form_error('org_terdekat', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="pendidikan" class="col-sm-2 col-form-label">Pendidikan Terakhir</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="pendidikan" name="pendidikan" value="<?= $user['pendidikan']; ?>">
                    <?= form_error('pendidikan', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="riwayat_pelatihan" class="col-sm-2 col-form-label">Riwayat Pelatihan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="riwayat_pelatihan" name="riwayat_pelatihan" value="<?= $user['riwayat_pelatihan']; ?>">
                    <?= form_error('riwayat_pelatihan', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="riwayat_kerja" class="col-sm-2 col-form-label">Riwayat Pekerjaan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="riwayat_kerja" name="riwayat_kerja" value="<?= $user['riwayat_kerja']; ?>">
                    <?= form_error('riwayat_kerja', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="skill" class="col-sm-2 col-form-label">Skill</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="skill" name="skill" value="<?= $user['skill']; ?>">
                    <?= form_error('skill', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="penempatan_kerja" class="col-sm-2 col-form-label">Bersedia Ditempatkan di Seluruh Kantor Perusahaan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="penempatan_kerja" name="penempatan_kerja" value="<?= $user['penempatan_kerja']; ?>">
                    <?= form_error('penempatan_kerja', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="penghasilan" class="col-sm-2 col-form-label">Penghasilan yang di Harapkan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="penghasilan" name="penghasilan" value="<?= $user['penghasilan']; ?>">
                    <?= form_error('penghasilan', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
            </div>


            <div class="form-group row justify-content-end">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>


            </form>


        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->