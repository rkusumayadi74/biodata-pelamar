<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="jumbotron">
        <div class="container">
            <img src="assets/img/ava2.jpg" class="rounded-circle float-left" alt="Rahman Kusumayadi">
            <h1 class="display-3">It's me Muhammad Nur Rahman Kusumayadi</h1>
            <p>Hello and welcome to My Portfolio.</p>
            <p><a class="btn btn-primary btn-lg" href="#" role="button">Access my Resume &raquo;</a></p>
        </div>
    </div>

    <div class="container">
        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-4">
                <h2>My Skills</h2>
                <p>I love to work in Web Technologies. I have skills to develop website, create custom wordpress themes and writing ebooks</p>
                <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
            </div>
            <div class="col-md-4">
                <h2>My Experience</h2>
                <p>I was an Internship at CV. Daya Kreasi Teknologi. When i still an intern i given a project about web developing. I make a Internet bills website and a company homepage with PHP, Javascript, CSS and Wordpress.</p>
                <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
            </div>
            <div class="col-md-4">
                <h2>My Education</h2>
                <p>I completed by bachelor in Computer Science from Mercu Buana University.</p>
                <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
            </div>
        </div>



    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->