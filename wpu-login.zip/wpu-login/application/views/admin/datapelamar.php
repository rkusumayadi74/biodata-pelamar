<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <form action="datapelamar">
        <label>Cari</label>
        <input type="text" name="cari">
        <input type="submit" value="Cari">
    </form>
    <?php
    if (isset($_GET['cari'])) {
        $cari = $_GET['cari'];
        echo "<b>Hasil pencarian : " . $cari . "</b>";
    }
    ?>


    <div class="row" style="overflow-x: auto;">
        <div class="col-lg">
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Email</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Posisi yang Dilamar</th>
                        <th scope="col">No. KTP</th>
                        <th scope="col">Tempat, Tanggal Lahir</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Agama</th>
                        <th scope="col">Golongan Darah</th>
                        <th scope="col">Status</th>
                        <th scope="col">Alamat KTP</th>
                        <th scope="col">Alamat Tinggal</th>
                        <th scope="col">No. Telpon</th>
                        <th scope="col">Orang Terdekat Yang Dapat Dihubungi</th>
                        <th scope="col">Pendidikan Terakhir</th>
                        <th scope="col">Riwayat Pelatihan</th>
                        <th scope="col">Riwayat Pekerjaan</th>
                        <th scope="col">Skill</th>
                        <th scope="col">Bersedia Ditempatkan di Seluruh Kantor Perusahaan</th>
                        <th scope="col">Penghasilan yang di Harapkan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($dataPelamar as $dp) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $dp['email']; ?></td>
                            <td><?= $dp['name']; ?></td>
                            <td><?= $dp['posisi']; ?></td>
                            <td><?= $dp['no_ktp']; ?></td>
                            <td><?= $dp['tempat_tanggal_lahir']; ?></td>
                            <td><?= $dp['jenis_kelamin']; ?></td>
                            <td><?= $dp['agama']; ?></td>
                            <td><?= $dp['golongan_darah']; ?></td>
                            <td><?= $dp['status']; ?></td>
                            <td><?= $dp['alamat_ktp']; ?></td>
                            <td><?= $dp['alamat_tinggal']; ?></td>
                            <td><?= $dp['no_telp']; ?></td>
                            <td><?= $dp['org_terdekat']; ?></td>
                            <td><?= $dp['pendidikan']; ?></td>
                            <td><?= $dp['riwayat_pelatihan']; ?></td>
                            <td><?= $dp['riwayat_kerja']; ?></td>
                            <td><?= $dp['skill']; ?></td>
                            <td><?= $dp['penempatan_kerja']; ?></td>
                            <td><?= $dp['penghasilan']; ?></td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>


        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Modal -->

<!-- Modal -->
<div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="newSubMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSubMenuModalLabel">Add New Sub Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('admin/datapelamar'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="title" name="title" placeholder="Submenu title">
                    </div>
                    <div class="form-group">
                        <select name="menu_id" id="menu_id" class="form-control">
                            <option value="">Select Menu</option>
                            <?php foreach ($menu as $m) : ?>
                                <option value="<?= $m['id']; ?>"><?= $m['menu']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="url" name="url" placeholder="Submenu url">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="icon" name="icon" placeholder="Submenu icon">
                    </div>
                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" name="is_active" id="is_active" checked>
                            <label class="form-check-label" for="is_active">
                                Active?
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>