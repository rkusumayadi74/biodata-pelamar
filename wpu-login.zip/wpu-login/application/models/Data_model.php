<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_model extends CI_Model
{
    public function getDataPelamar()
    {
        $query = "SELECT `user`.*, `name`,`email`,`no_ktp`,`tempat_tanggal_lahir`,`jenis_kelamin`,`agama`,`golongan_darah`,`status`,`alamat_ktp`,`alamat_tinggal`,`no_telp`,`org_terdekat`,`pendidikan`,`riwayat_pelatihan`,`riwayat_kerja`,`skill`,`penempatan_kerja`,`penghasilan`
                  FROM `user`
                  WHERE role_id= 2";
        return $this->db->query($query)->result_array();
    }
}
